package com.insight.ai_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
